-- CreateIndex
CREATE INDEX "ReferralStats_lastPayoutAt_idx" ON "ReferralStats"("lastPayoutAt");
