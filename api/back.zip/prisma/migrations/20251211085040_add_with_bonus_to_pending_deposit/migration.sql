-- AlterTable
ALTER TABLE "PendingDeposit" ADD COLUMN     "withBonus" BOOLEAN NOT NULL DEFAULT false;
