/**
 * 🎮 PLINKO GAME PAGE - С REST API ЗАПРОСАМИ
 * Использует и Socket.IO и REST API
 */

import React, { useState, useEffect, useRef } from 'react';
import io, { Socket } from 'socket.io-client';
import { useAuth } from '../../../context/AuthContext';
import { Button } from '../../ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../../ui/card';
import { Input } from '../../ui/input';
import { Label } from '../../ui/label';
import { Slider } from '../../ui/slider';
import { toast } from 'sonner';
import './plinko.css';

const PLINKO_SERVER_URL = import.meta.env.PLINKO_SERVER_URL || 'http://localhost:5600';

interface GameResult {
  success: boolean;
  gameId?: string;
  result?: 'win' | 'loss' | 'draw';
  payout?: number;
  betAmount?: number;
  winAmount?: number;
  newBalance?: number;
  path?: number[];
  error?: string;
}

interface GameStats {
  totalGames: number;
  totalBet: number;
  totalWin: number;
  profit: number;
  roi: number;
}

interface GameHistoryItem {
  gameId: string;
  payout: number;
  betAmount: number;
  winAmount: number;
  result: 'win' | 'loss' | 'draw';
  createdAt: string;
}

const PlinkoGame = () => {
  const { user, token, isAuthenticated } = useAuth();
  
  if (!isAuthenticated || !user) {
    return (
      <div className="flex items-center justify-center h-96 bg-slate-900 rounded-lg">
        <div className="text-center">
          <p className="text-2xl mb-4">🔐 Please login first</p>
          <p className="text-gray-400">You need to be logged in to play Plinko</p>
        </div>
      </div>
    );
  }

  const socketRef = useRef<Socket | null>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // Game state
  const [betAmount, setBetAmount] = useState<number>(10);
  const [rowCount, setRowCount] = useState<number>(8);
  const [risk, setRisk] = useState<'low' | 'medium' | 'high'>('medium');
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [gameHistory, setGameHistory] = useState<GameHistoryItem[]>([]);
  const [stats, setStats] = useState<GameStats | null>(null);
  const [ballPath, setBallPath] = useState<number[]>([]);
  const [lastResult, setLastResult] = useState<GameResult | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [balance, setBalance] = useState<number>(0);
  const [balanceLoading, setBalanceLoading] = useState<boolean>(true);

  // ====================================
  // REST API ФУНКЦИИ
  // ====================================

  /**
   * 🔥 ЗАПРОС БАЛАНСА ЧЕРЕЗ REST API
   */
  const fetchBalance = async () => {
    try {
      setBalanceLoading(true);
      console.log('🔄 Fetching balance via REST API...');
      
      const response = await fetch(
        `${PLINKO_SERVER_URL}/api/v1/plinko/balance`,
        {
          method: 'GET',
          headers: {
            'Authorization': `Bearer ${token}`,
            'X-User-ID': user.id.toString(),
            'Content-Type': 'application/json'
          }
        }
      );

      const data = await response.json();
      console.log('💰 Balance API response:', data);

      if (data.success) {
        setBalance(data.balance);
        console.log(`✅ Balance loaded: ${data.balance} ${data.currency}`);
        toast.success(`Balance: ${data.balance.toFixed(2)} ${data.currency}`);
      } else {
        console.error('❌ Balance error:', data.error);
        toast.error(`Balance error: ${data.error}`);
      }
    } catch (error) {
      console.error('❌ Failed to fetch balance:', error);
      toast.error('Failed to load balance');
    } finally {
      setBalanceLoading(false);
    }
  };

  /**
   * 🔥 ЗАПРОС ИСТОРИИ ЧЕРЕЗ REST API
   */
  const fetchHistory = async (limit: number = 10) => {
    try {
      console.log('🔄 Fetching history via REST API...');
      
      const response = await fetch(
        `${PLINKO_SERVER_URL}/api/v1/plinko/history?limit=${limit}`,
        {
          method: 'GET',
          headers: {
            'Authorization': `Bearer ${token}`,
            'X-User-ID': user.id.toString(),
            'Content-Type': 'application/json'
          }
        }
      );

      const data = await response.json();
      console.log('📜 History API response:', data);

      if (data.success) {
        setGameHistory(data.data);
        console.log(`✅ History loaded: ${data.data.length} games`);
      } else {
        console.error('❌ History error:', data.error);
      }
    } catch (error) {
      console.error('❌ Failed to fetch history:', error);
    }
  };

  /**
   * 🔥 ЗАПРОС СТАТИСТИКИ ЧЕРЕЗ REST API
   */
  const fetchStats = async () => {
    try {
      console.log('🔄 Fetching stats via REST API...');
      
      const response = await fetch(
        `${PLINKO_SERVER_URL}/api/v1/plinko/stats`,
        {
          method: 'GET',
          headers: {
            'Authorization': `Bearer ${token}`,
            'X-User-ID': user.id.toString(),
            'Content-Type': 'application/json'
          }
        }
      );

      const data = await response.json();
      console.log('📊 Stats API response:', data);

      if (data.success) {
        setStats(data.data);
        console.log(`✅ Stats loaded:`, data.data);
      } else {
        console.error('❌ Stats error:', data.error);
      }
    } catch (error) {
      console.error('❌ Failed to fetch stats:', error);
    }
  };

  /**
   * 🔥 ЗАПРОС ИГРЫ ЧЕРЕЗ REST API
   */
  const fetchGame = async (gameId: string) => {
    try {
      console.log('🔄 Fetching game via REST API...');
      
      const response = await fetch(
        `${PLINKO_SERVER_URL}/api/v1/plinko/game/${gameId}`,
        {
          method: 'GET',
          headers: {
            'Authorization': `Bearer ${token}`,
            'X-User-ID': user.id.toString(),
            'Content-Type': 'application/json'
          }
        }
      );

      const data = await response.json();
      console.log('🎮 Game API response:', data);

      if (data.success) {
        console.log(`✅ Game loaded:`, data.data);
        return data.data;
      } else {
        console.error('❌ Game error:', data.error);
      }
    } catch (error) {
      console.error('❌ Failed to fetch game:', error);
    }
  };

  /**
   * 🔥 НАЧАЛО ИГРЫ ЧЕРЕЗ REST API (вместо Socket.IO)
   */
  const playGameViaAPI = async () => {
    try {
      setIsPlaying(true);
      console.log('🎮 Starting game via REST API...');
      console.log(`POST ${PLINKO_SERVER_URL}/api/v1/plinko/play`);
      console.log('Body:', {
        betAmount,
        rowCount,
        risk
      });

      const response = await fetch(
        `${PLINKO_SERVER_URL}/api/v1/plinko/play`,
        {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${token}`,
            'X-User-ID': user.id.toString(),
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            betAmount,
            rowCount,
            risk
          })
        }
      );

      const data = await response.json();
      console.log('🎲 Game result via REST API:', data);

      if (data.success) {
        setBallPath(data.path || []);
        setLastResult(data);
        
        // 🔥 ОБНОВЛЯЕМ БАЛАНС
        if (data.newBalance !== undefined) {
          setBalance(data.newBalance);
          console.log(`✅ Balance updated: ${data.newBalance}`);
        }

        toast.success(`${data.result === 'win' ? '🎉 WIN' : '💀 LOSS'} - ${data.payout}x`);

        // Обновляем историю и статистику
        await fetchHistory(10);
        await fetchStats();
      } else {
        toast.error(data.error || 'Game failed');
      }
    } catch (error) {
      console.error('❌ Failed to play game via API:', error);
      toast.error('Failed to start game');
    } finally {
      setIsPlaying(false);
    }
  };

  // ====================================
  // SOCKET.IO ПОДКЛЮЧЕНИЕ (РЕЗЕРВНОЕ)
  // ====================================

  useEffect(() => {
    if (!user || !token) return;

    try {
      socketRef.current = io(PLINKO_SERVER_URL, {
        reconnection: true,
        reconnectionDelay: 1000,
        reconnectionDelayMax: 5000,
        reconnectionAttempts: 5,
        transports: ['websocket', 'polling'],
        auth: {
          token: token,
          userId: user.id
        }
      });

      socketRef.current.on('connect', () => {
        console.log('✅ Socket.IO Connected to Plinko server');
        toast.success('Connected to Plinko (WebSocket)');
        setIsLoading(false);
      });

      socketRef.current.on('disconnect', () => {
        console.log('❌ Socket.IO Disconnected from Plinko');
      });

      socketRef.current.on('error', (error: any) => {
        console.error('❌ Socket.IO error:', error);
      });

      return () => {
        if (socketRef.current) {
          socketRef.current.disconnect();
        }
      };
    } catch (error) {
      console.error('Failed to connect Socket.IO:', error);
      setIsLoading(false);
    }
  }, [user, token]);

  // ====================================
  // ЗАГРУЗКА НАЧАЛЬНЫХ ДАННЫХ
  // ====================================

  useEffect(() => {
    if (user?.id && token && !isLoading) {
      // Загружаем все данные при открытии игры
      fetchBalance();
      fetchHistory(10);
      fetchStats();
    }
  }, [user?.id, token, isLoading]);

  // ====================================
  // ФУНКЦИЯ ИГРЫ (MAIN)
  // ====================================

  const handlePlayGame = async () => {
    if (betAmount > balance) {
      toast.error(`Insufficient balance. Have: ${balance}, Need: ${betAmount}`);
      return;
    }

    if (betAmount <= 0) {
      toast.error('Invalid bet amount');
      return;
    }

    setBallPath([]);
    setLastResult(null);

    // 🔥 ИСПОЛЬЗУЕМ REST API ВМЕСТО SOCKET.IO
    await playGameViaAPI();
  };

  // ====================================
  // РИСОВАНИЕ ДОСКИ
  // ====================================

  useEffect(() => {
    if (!canvasRef.current) return;

    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = canvas.width;
    const height = canvas.height;

    ctx.fillStyle = '#1a1a2e';
    ctx.fillRect(0, 0, width, height);

    const pegRadius = 5;
    const rows = rowCount;
    const startX = width / 2;
    const startY = 30;
    const spacing = width / (rows + 2);

    // Пеги
    ctx.fillStyle = '#fff';
    for (let row = 0; row <= rows; row++) {
      const numPegs = row + 1;
      const rowStartX = startX - (numPegs - 1) * spacing / 2;
      for (let i = 0; i < numPegs; i++) {
        const x = rowStartX + i * spacing;
        const y = startY + row * (spacing * 0.8);
        ctx.beginPath();
        ctx.arc(x, y, pegRadius, 0, Math.PI * 2);
        ctx.fill();
      }
    }

    // Слоты
    ctx.fillStyle = '#4ade80';
    ctx.strokeStyle = '#fff';
    ctx.lineWidth = 2;
    for (let i = 0; i <= rows; i++) {
      const x = startX - (rows / 2) * spacing + i * spacing;
      const y = startY + (rows + 1) * (spacing * 0.8);
      ctx.fillRect(x - spacing / 4, y, spacing / 2, 30);
      ctx.strokeRect(x - spacing / 4, y, spacing / 2, 30);
    }

    // Путь
    if (ballPath && ballPath.length > 0) {
      ctx.strokeStyle = '#ff6b6b';
      ctx.lineWidth = 2;
      ctx.fillStyle = '#ff6b6b';

      for (let i = 0; i < ballPath.length; i++) {
        const position = ballPath[i];
        const x = startX - (rows / 2) * spacing + position * spacing;
        const y = startY + i * (spacing * 0.8);

        if (i > 0) {
          const prevX = startX - (rows / 2) * spacing + ballPath[i - 1] * spacing;
          const prevY = startY + (i - 1) * (spacing * 0.8);
          ctx.beginPath();
          ctx.moveTo(prevX, prevY);
          ctx.lineTo(x, y);
          ctx.stroke();
        }

        ctx.beginPath();
        ctx.arc(x, y, pegRadius + 2, 0, Math.PI * 2);
        ctx.fill();
      }
    }
  }, [ballPath, rowCount]);

  const isValidBet = betAmount > 0 && betAmount <= balance;

  return (
    <div className="plinko-container">
      <div className="plinko-main">
        {/* ДОСКА ИГРЫ */}
        <Card className="plinko-board-card">
          <CardHeader>
            <CardTitle>🎮 Plinko Game</CardTitle>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="plinko-loading">
                <span className="plinko-loading-spinner">⏳</span>
                <p>Connecting to game server...</p>
              </div>
            ) : (
              <>
                <canvas
                  ref={canvasRef}
                  width={400}
                  height={500}
                  className="plinko-canvas"
                />

                {lastResult && (
                  <div className={`plinko-result ${lastResult.result === 'win' ? 'win' : 'loss'}`}>
                    <p className="text-2xl">
                      {lastResult.result === 'win' ? '🎉 WIN!' : '💀 LOSS'}
                    </p>
                    <p className="text-xl">{lastResult.payout}x Multiplier</p>
                    <p className="text-lg">
                      {lastResult.result === 'win'
                        ? `+${lastResult.winAmount}`
                        : `-${lastResult.betAmount}`
                      } USDT
                    </p>
                  </div>
                )}
              </>
            )}
          </CardContent>
        </Card>

        {/* САЙДБАР */}
        <div className="plinko-sidebar">
          {/* БАЛАНС */}
          <Card>
            <CardHeader>
              <CardTitle>💰 Balance</CardTitle>
            </CardHeader>
            <CardContent>
              {balanceLoading ? (
                <p>Loading balance...</p>
              ) : (
                <div className="text-center">
                  <p className="text-4xl font-bold text-green-500">
                    {balance.toFixed(2)}
                  </p>
                  <p className="text-gray-400">USDT</p>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={fetchBalance}
                    className="mt-2"
                  >
                    🔄 Refresh
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>

          {/* БЕТ */}
          <Card>
            <CardHeader>
              <CardTitle>🎲 Bet Amount</CardTitle>
            </CardHeader>
            <CardContent>
              <div>
                <Label>Amount (USDT)</Label>
                <Input
                  type="number"
                  min="0.01"
                  step="0.01"
                  value={betAmount}
                  onChange={(e) => setBetAmount(parseFloat(e.target.value) || 0)}
                  disabled={isPlaying}
                />
                <div className="flex gap-2 mt-2">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => setBetAmount(Math.max(0.01, betAmount - 10))}
                    disabled={isPlaying}
                  >
                    -10
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => setBetAmount(betAmount + 10)}
                    disabled={isPlaying}
                  >
                    +10
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => setBetAmount(balance * 0.1)}
                    disabled={isPlaying}
                  >
                    10%
                  </Button>
                </div>
              </div>

              <div className="text-sm mt-4 space-y-2">
                <p>💳 Min Bet: <span className="font-bold">0.01</span> USDT</p>
                <p>📊 Max Bet: <span className="font-bold">{balance.toFixed(2)}</span> USDT</p>
                <p className={isValidBet ? 'text-green-500' : 'text-red-500'}>
                  {isValidBet ? '✅ Valid bet' : '❌ Invalid bet'}
                </p>
              </div>
            </CardContent>
          </Card>

          {/* ПАРАМЕТРЫ */}
          <Card>
            <CardHeader>
              <CardTitle>⚙️ Game Settings</CardTitle>
            </CardHeader>
            <CardContent>
              <div>
                <Label>Rows: {rowCount}</Label>
                <Slider
                  min={8}
                  max={16}
                  step={1}
                  value={[rowCount]}
                  onValueChange={(val) => setRowCount(val[0])}
                  disabled={isPlaying}
                />
              </div>

              <div className="mt-4">
                <Label>Risk Level</Label>
                <div className="flex gap-2 mt-2">
                  {(['low', 'medium', 'high'] as const).map((r) => (
                    <Button
                      key={r}
                      size="sm"
                      variant={risk === r ? 'default' : 'outline'}
                      onClick={() => setRisk(r)}
                      disabled={isPlaying}
                    >
                      {r === 'low' ? '🟢' : r === 'medium' ? '🟡' : '🔴'} {r}
                    </Button>
                  ))}
                </div>
              </div>

              <Button
                onClick={handlePlayGame}
                disabled={isPlaying || !isValidBet}
                size="lg"
                className="w-full mt-4"
              >
                {isPlaying ? '🎲 Playing...' : '▶️ PLAY'}
              </Button>
            </CardContent>
          </Card>

          {/* СТАТИСТИКА */}
          {stats && (
            <Card>
              <CardHeader>
                <CardTitle>📊 Statistics</CardTitle>
              </CardHeader>
              <CardContent className="text-sm space-y-2">
                <p>Games: <span className="font-bold">{stats.totalGames}</span></p>
                <p>Total Bet: <span className="font-bold">{stats.totalBet?.toFixed(2)}</span> USDT</p>
                <p>Total Win: <span className="font-bold text-green-500">{stats.totalWin?.toFixed(2)}</span> USDT</p>
                <p>Profit: <span className={`font-bold ${stats.profit >= 0 ? 'text-green-500' : 'text-red-500'}`}>{stats.profit?.toFixed(2)}</span> USDT</p>
                <p>ROI: <span className="font-bold">{stats.roi?.toFixed(2)}%</span></p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>

      {/* ИСТОРИЯ */}
      <Card className="plinko-history">
        <CardHeader>
          <CardTitle>📜 Recent Games</CardTitle>
        </CardHeader>
        <CardContent>
          {gameHistory && gameHistory.length > 0 ? (
            <div className="overflow-x-auto">
              <table>
                <thead>
                  <tr>
                    <th>Payout</th>
                    <th>Bet</th>
                    <th>Win</th>
                    <th>Result</th>
                    <th>Time</th>
                  </tr>
                </thead>
                <tbody>
                  {gameHistory.map((game, idx) => (
                    <tr key={idx}>
                      <td>{game.payout?.toFixed(2)}x</td>
                      <td>{game.betAmount?.toFixed(2)}</td>
                      <td className="text-green-500">{game.winAmount?.toFixed(2)}</td>
                      <td className={game.result === 'win' ? 'text-green-500' : 'text-red-500'}>
                        {game.result?.toUpperCase()}
                      </td>
                      <td>{new Date(game.createdAt).toLocaleTimeString()}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <p>No games yet. Play to see history!</p>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default PlinkoGame;